# CA del servidor
openssl req -x509 -nodes -days 4000 -newkey rsa:2048 -keyout s-ca_key.pem -out s-ca_cert.pem -subj "/C=ES/ST=GI/L=SS/O=MISE/OU=RC-LABS/CN=CA_SERV-MISE/emailAddress=ca-serv-mise@mise.lab/"
openssl rand -hex 8  > s-ca_cert.srl

# certificado para el servidor firmado por la CA del servidor
openssl req  -nodes  -newkey rsa:2048 -out s_solicitud.pem -keyout s_key.pem  -subj "/C=ES/ST=GI/L=SS/O=MISE/OU=RC-LABS/CN=SERV-MISE/emailAddress=serv-mise@mise.lab/"
openssl x509 -req -days 4000 -in s_solicitud.pem -out s_cert.pem -CA s-ca_cert.pem -CAkey s-ca_key.pem -CAserial s-ca_cert.srl

