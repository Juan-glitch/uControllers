﻿/***********************************************/
/*** echo_ssl-client.c                           ***/
/**********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <sys/socket.h>
#include <resolv.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <openssl/ssl.h>
#include <openssl/err.h>

#define CA_CERT  "./certificados/s-ca_cert.pem"

#define CHK_NULL(x) if ((x) == NULL) { exit(-1); }
#define CHK_ERR(err,s) if ((err) == -1) { perror(s); exit(-2);  }
#define CHK_SSL(err) if ((err) == -1) { ERR_print_errors_fp(stderr); exit(-3); }

// Función auxiliar: mostrar certificado servidor
void ver_certificado(SSL *ssl);

/*--- main ----------------*/
int main()
{   char buf[1024];
    struct sockaddr_in dir;
    int leidos, err, sock;
    
    SSL_CTX *ctx;
    SSL *ssl;
    const SSL_METHOD *method;

    //Crear socket:
	sock = socket(PF_INET, SOCK_STREAM, 0);
    CHK_ERR(sock, "NO se ha establecido el socket");

    // Establecer dirección servidor
    bzero(&dir, sizeof(dir));			   
    dir.sin_family = AF_INET;
    inet_aton("127.0.0.1", &dir.sin_addr);   
    // inet_aton("127.0.0.1", &dir.sin_addr.s_addr);
    dir.sin_port = htons(7777);
    
    //Abrir conexión:    
    err = connect(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "Conexión no aceptada");
    
    // Iniciar contexto SSL:
    // cargando algoritmos y mensajes de error
	SSL_library_init();
	SSL_load_error_strings();
    
    // Establecer método y contexto
	method = TLS_client_method();
	//method = SSLv23_client_method();  
	ctx = SSL_CTX_new(method);	     
        CHK_NULL(ctx);

	// Cargar el certificado de la CA del servidor,
	// para verificar el certificado del servidor 
	err = SSL_CTX_load_verify_locations(ctx, CA_CERT, NULL);
        CHK_SSL(err);

	// Requerir la verificación del certificado del servidor 
	SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
	SSL_CTX_set_verify_depth(ctx, 1);

    // Obtener estado SSL del contexto establecido
	ssl = SSL_new(ctx);     
        CHK_NULL(ssl);
    
    // Incorporar socket al estado SSL
	SSL_set_fd(ssl, sock);	

    // Establecer conexión segura
	err = SSL_connect(ssl);
        CHK_SSL(err);
	printf("Conectado con cifrado %s.\n\n", SSL_get_cipher(ssl));

	//Verificar certificado del servidor
    if(SSL_get_verify_result(ssl) == X509_V_OK)
    printf("Éxito en la verificación del servidor. \n");

    ver_certificado(ssl);
    
    //Enviar mensaje:
    printf("Mensaje: ");
    fgets(buf,sizeof(buf),stdin);
    err = SSL_write(ssl, buf, strlen(buf)+1);
    CHK_ERR(err, "Error de escritura");
    
    //Leer respuesta:
    leidos = SSL_read(ssl, buf, sizeof(buf));
    CHK_ERR(leidos, "Error de lectura");
    
    buf[leidos] = '\0';
    printf("Recibido: %s", buf);
    
    //Cerrar conexión segura:
    close(sock);
    SSL_free(ssl);
    SSL_CTX_free(ctx);
    
    exit(0);
}

// Mostrar el certificado del servidor
void ver_certificado(SSL *ssl) 
{
	X509 *serv_cert;
	char *line;

	serv_cert = SSL_get_peer_certificate(ssl);	/* obtener el certificado */
	if ( serv_cert == NULL )
 	printf("No hay certificado.\n");
	else
 	{
		 printf("Certificado del servidor:\n");
		 line = X509_NAME_oneline(X509_get_subject_name(serv_cert), 0, 0);
		 	CHK_NULL(line);
		 printf("Subject: %s\n", line);
		 free(line);

		 line = X509_NAME_oneline(X509_get_issuer_name(serv_cert), 0, 0);
		 	CHK_NULL(line);
		 printf("Issuer: %s\n\n", line);
		 free(line);

		 X509_free(serv_cert);
 	}

}
