﻿/***********************************************/
/*** echo_client.c                           ***/
/**********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <sys/socket.h>
#include <resolv.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(-1);  }


/*--- main ----------------*/
int main()
{   char buf[1024];
    struct sockaddr_in dir;
    int leidos, err, sock;
    
    //Crear socket:
    sock = socket(PF_INET, SOCK_STREAM, 0);
    CHK_ERR(sock, "NO se ha establecido el socket");

    // Establecer dirección servidor
    bzero(&dir, sizeof(struct sockaddr));			   
    dir.sin_family = AF_INET;
    //inet_aton("127.0.1.1", &dir.sin_addr);   
    dir.sin_addr.s_addr = inet_addr("127.0.0.1");
    dir.sin_port = htons(7777);
    
    //Abrir conexión:    
    err = connect(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "Conexión no aceptada");

    //Enviar mensaje:
    printf("Mensaje: ");
    fgets(buf,sizeof(buf),stdin);
    err = write(sock, buf, strlen(buf)+1);
    CHK_ERR(err, "Error de escritura");
    
    //Leer respuesta:
    leidos = read(sock, buf, sizeof(buf));
    CHK_ERR(leidos, "Error de lectura");
    
    buf[leidos] = '\0';
    printf("Recibido: %s", buf);
    
    //Cerrar conexión:
    close(sock);
    
    exit(0);
}


