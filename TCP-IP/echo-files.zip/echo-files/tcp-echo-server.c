﻿/************************************************/
/*** echo_server.c                             ***/
/************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <malloc.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <resolv.h>

#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(-1);}

/*--- main ----------------*/
int main()
{   char buf[1024];
    struct sockaddr_in dir, clientdir;
    int leidos, err;
    int sock, sock_dialogo;
    socklen_t len = sizeof (struct sockaddr); // requiere valor inicial
    
    //Crear socket:
    sock = socket(PF_INET, SOCK_STREAM, 0);
    CHK_ERR(sock, "No se ha establecido el socket");

    //Asignar dirección al socket:
    bzero(&dir, sizeof(struct sockaddr));			   
    dir.sin_family = AF_INET;
    dir.sin_addr.s_addr = htonl(INADDR_ANY);
    dir.sin_port = htons(7777);
    
    err = bind(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "No se puede asignar dirección");

    //Establecer como socket de escucha:
    err = listen(sock, 5);
    CHK_ERR(err, "No se puede configurar el puerto de escucha");

    //Repetir:
    while(1) 
    {
        //Aceptar conexión:
       	sock_dialogo = accept(sock, (struct sockaddr *)&clientdir, &len);		/* accept connection */
        printf("Conexión desde: %s:%d\n", inet_ntoa(clientdir.sin_addr), ntohs(clientdir.sin_port));

        //Leer mensaje:
    	leidos = read(sock_dialogo, buf, 1024);
        CHK_ERR(leidos, "Error de lectura");
 
        buf[leidos] = '\0';
        printf("Mensaje cliente: %s \n", buf);
				
        //Responder:
        err = write(sock_dialogo, buf, leidos);	/* send reply */
        CHK_ERR(err, "Error de escritura");
        
        //Cerrar conexión:
    	close(sock_dialogo);
	}
	
    close(sock);
}


