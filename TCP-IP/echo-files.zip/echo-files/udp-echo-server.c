﻿/************************************************/
/*** echo_server.c                             ***/
/************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <resolv.h>

#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(-1);}

/*--- main ----------------*/
int main()
{   char buf[1024];
    struct sockaddr_in dir;
    struct sockaddr_in clientdir;
    int leidos, err;
    int sock;
    socklen_t len = sizeof(struct sockaddr); //requiere valor inicial

    
    //Crear socket:
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    CHK_ERR(sock, "No se ha establecido el socket");

    //Asignar dirección al socket:
    dir.sin_family = AF_INET;
    dir.sin_addr.s_addr = htonl(INADDR_ANY);
    dir.sin_port = htons(7777);
    bzero(&(dir.sin_zero), 8);
    
    err = bind(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "No se puede asignar dirección");

    //Repetir:
    while(1) 
    {
        //Leer mensaje:
    	leidos = recvfrom(sock, buf, 1024, 0, (struct sockaddr *)&clientdir, (socklen_t *)&len);
        CHK_ERR(leidos, "Error de lectura");
        
        printf("Recibido desde: %s:%d\n", inet_ntoa(clientdir.sin_addr), ntohs(clientdir.sin_port));
       
        buf[leidos] = '\0';
        printf("Mensaje cliente: %s \n", buf);
        
        //Responder:
        err = sendto(sock, buf, leidos+1, 0, (struct sockaddr *)&clientdir, len);	
        CHK_ERR(err, "Error de escritura");

     }        

     //Cerrar conexión:
     close(sock);
}


