﻿/************************************************/
/*** tcp_server.c                             ***/
/************************************************/



#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h> 
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h> 

#include <openssl/err.h>
#include <openssl/ssl.h>

#define CERTFILE "./certificados/s_cert.pem"
#define KEYFILE  "./certificados/s_key.pem"

#define CHK_NULL(x) if ((x)==NULL ) exit(-1);
#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(-2); }
#define CHK_SSL(err) if ((err)==-1) { ERR_print_errors_fp(stderr); exit(-3); }


/*--- main ----------------*/
int main()
{   char buf[1024];
    struct sockaddr_in dir, clientdir;
    int leidos, err;
    socklen_t len = sizeof (struct sockaddr);
    int sock, sock_dialogo;
    
    SSL_CTX *ctx;
    SSL *ssl;
    const SSL_METHOD *method;

    //Crear socket:
    sock = socket(AF_INET, SOCK_STREAM, 0);
    CHK_ERR(sock, "No se ha establecido el socket");

    //Asignar dirección al socket:
    bzero(&dir, sizeof(struct sockaddr));			   
    dir.sin_family = AF_INET;
    dir.sin_addr.s_addr = htonl(INADDR_ANY);
    dir.sin_port = htons(7777);
    
    err = bind(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "No se puede asignar dirección");

    //Establecer como socket de escucha:
    err = listen(sock, 5);
    CHK_ERR(err, "No se puede configurar el puerto de escucha");

    // Inicializar contexto SSL
    SSL_library_init();
    SSL_load_error_strings();

    method = TLS_server_method();
    //method = SSLv23_server_method();  
    ctx = SSL_CTX_new(method);
    CHK_NULL(ctx);

    // Cargar cerfificados desde ficheros
    err = SSL_CTX_use_certificate_file(ctx, CERTFILE, SSL_FILETYPE_PEM) ;
    CHK_SSL(err);
    // Cargar clave privada
    err = SSL_CTX_use_PrivateKey_file(ctx, KEYFILE, SSL_FILETYPE_PEM) ;
    CHK_SSL(err);
    // Verificar clave privada
    err = SSL_CTX_check_private_key(ctx);
    CHK_ERR(err,"Clave privada no se corresponde con certificado\n");


    //Repetir:
    while(1) 
    {
        // Bloqueo a la espera de aceptar conexión:
    	sock_dialogo = accept(sock, (struct sockaddr*)&clientdir, &len);		/* accept connection */
        CHK_ERR(sock_dialogo, "Conexión no establecida");
        printf("Conexión desde: %s:%d\n", inet_ntoa(clientdir.sin_addr), ntohs(clientdir.sin_port));
 
        // Obtener estado SSL del contexto establecido
        ssl = SSL_new(ctx);     
        CHK_NULL(ssl);
    
        // Incorporar socket al estado SSL
        SSL_set_fd(ssl, sock_dialogo);	

        // Establecer conexión segura
        err = SSL_accept(ssl);
        CHK_SSL(err);
        printf("Conexión cifrada con %s\n", SSL_get_cipher(ssl));

        //Leer mensaje:
        memset(buf, 0, 1024);
        leidos = SSL_read(ssl, buf, 1024);
        CHK_SSL(leidos);
 
        buf[leidos] = '\0';
        printf("Mensaje cliente: %s \n", buf);
				
        //Responder:
        err = SSL_write(ssl, buf, leidos);	
        CHK_ERR(err, "Error de escritura");
        
        //Cerrar conexión:
    	close(sock_dialogo);
	}
    
    // Liberar contexto ssl
    SSL_free(ssl);
    SSL_CTX_free(ctx);
    
    exit(0);

}


