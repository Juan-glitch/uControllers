#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include <openssl/ssl.h>
#include <openssl/err.h>

#define CA_CERT  "./certificados/s-ca_cert.pem"

#define CHK_NULL(x) if ((x) == NULL) { exit(-1); }
#define CHK_ERR(err,s) if ((err) == -1) { perror(s); exit(-2);  }
#define CHK_SSL(err) if ((err) == -1) { ERR_print_errors_fp(stderr); exit(-3); }

#define TRUE 1
#define FALSE 0
#define TAMBUF 32    // límite lectura/escritura

// Variables globales
int DEBUG;

// Función comunicación segura con el servidor
void send_receive(SSL *ssl, int comando, int param);

// ------------------------------- MAIN ------------------------------------------------------------------------------//
int main(int argc, char *argv[])
{
    int option, ident, aleat;
    char buf[TAMBUF];

	if(argc < 3){
		printf("usage: %s @IP #puerto -D\n",argv[0]);
		exit(1);
	}
	DEBUG = FALSE;
	if(argc == 4)
		if(strcmp(argv[3],"-D") == 0)
			DEBUG = TRUE;

/* --- Establecer comunicación segura --- */
	int sock, err;
	struct sockaddr_in serv_dir;
	SSL *ssl;
	SSL_CTX *ctx;
	const SSL_METHOD *method;

	sock = socket(AF_INET,SOCK_STREAM, 0);
  	CHK_ERR(sock,"Error apertura de socket");

	// Dirección del servidor
	serv_dir.sin_family = AF_INET;
	inet_aton(argv[1],&serv_dir.sin_addr);
	serv_dir.sin_port = htons(atoi(argv[2]));

	// Enviar peticion conexion TCP al servidor
	err = connect(sock, (struct sockaddr *)&serv_dir, sizeof(serv_dir) );
	CHK_ERR(err, "No acepta conexion");

  // Inicializar contexto SSL
	SSL_library_init();
	SSL_load_error_strings();			  /* cargar todos los mensajes de error */

	method = TLS_client_method();  /* crear nueva instancia método */
	ctx = SSL_CTX_new(method);	     /* crear nuevo contexto */
		CHK_NULL(ctx);

	/* Cargar el certificado de la CA del servidor,
	   para verificar el certificado del servidor */
	err = SSL_CTX_load_verify_locations(ctx, CA_CERT, NULL);
		CHK_SSL(err);

	/* Habilitar flag en el contexto para requerir
	   la verificación del certificado del servidor */
	SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, NULL);
	SSL_CTX_set_verify_depth(ctx, 1);

	ssl = SSL_new(ctx);     /* obtener nuevo estado ssl con contexto definido */
		CHK_NULL(ssl);
	SSL_set_fd(ssl, sock);	/* establecer socket en el estado ssl */

	err = SSL_connect(ssl);
		CHK_SSL(err);
	printf("Conectado con %s cifrado.\n", SSL_get_cipher(ssl));

	if(SSL_get_verify_result(ssl) == X509_V_OK)
    printf("Éxito en la verificación del servidor. \n");

  // Visualizar el certificado del servidor
	X509 *serv_cert;
	char *line;

	serv_cert = SSL_get_peer_certificate(ssl);	/* obtener el certificado */
	if ( serv_cert == NULL )
 	printf("No hay certificado.\n");
	else
 	{
		 printf("Certificado del servidor:\n");
		 line = X509_NAME_oneline(X509_get_subject_name(serv_cert), 0, 0);
		 	CHK_NULL(line);
		 printf("Subject: %s\n", line);
		 free(line);

		 line = X509_NAME_oneline(X509_get_issuer_name(serv_cert), 0, 0);
		 	CHK_NULL(line);
		 printf("Issuer: %s\n", line);
		 free(line);

		 X509_free(serv_cert);
 	}
	sleep(2);


/* --- Protocolo de aplicación --- */
	srand((unsigned) time(NULL));   // inicializar generador aleatorio

	do{
		option = ident = aleat = -1;
		//bzero(buf,TAMBUF);
		memset(buf, 0, TAMBUF);
		system("clear");
		printf("\nCliente para Interacción con Placa Altera\n");
		printf("--------------------------------------\n");
		printf(" 1. Mostrar un número en binario\n");
		printf(" 2. Codificar un número en binario\n");
		printf(" 3. Borrar estado placa\n");
		printf(" 4. Salir\n");
		printf("Elige una opción (1-4): ");
		fgets(buf,sizeof(buf),stdin);
		sscanf(buf,"%d",&option);
		switch(option){
		    // SHOW
			case 1:
				printf("\n  Indica el número (0..1023) que se mostrará en binario al operario:   ");
				fgets(buf,sizeof(buf),stdin);
				sscanf(buf,"%d",&ident);
				if (ident<0 || ident>1023) {
					printf("\n  **** Warning: Número entre 0 y 1023 **** \n");
					sleep(2);
					break;
				}
				send_receive(ssl, 0, ident);
				break;
			// TEST
			case 2:
				printf("\n  Indica tamaño en bits (1..10):  ");
				fgets(buf,sizeof(buf),stdin);
				sscanf(buf,"%d",&ident);
				if (ident<1 || ident>10) {
					printf("\n  **** Warning: Número entre 1 y 10 **** \n");
					sleep(2);
					break;
				}
				aleat = (rand() % (int) (pow(2, ident-1)) ) + (int) pow(2, ident-1);
				printf("\n  Mediante los switches, el operario debe codificar en binario el número <<  %d  >> : \n", aleat);
				send_receive(ssl, 1, aleat);
				break;
			// WIPE
			case 3:
				printf("\n  El operario debe situar todos los switches en su posición inicial,\n");
				send_receive(ssl, 2, 0);
				break;
			// EXIT
			case 4:
				// exit
				send_receive(ssl, 3, 10); 
				break;
			default:
				printf("\n**** Opción no válida **** \n");
				sleep(1);
				break;
		}
	} while (option != 4);

	printf ("\n Hasta la próxima \n \n");
	//Cerrar conexión segura TCP
	close(sock);
	SSL_free(ssl);
	SSL_CTX_free(ctx);

	exit(0);
}


// ---------------------------------- FUNCIONES ------------------------------------------------//

void send_receive(SSL *ssl, int comando, int param) {
	int tam;
	int msg;
    char buf[TAMBUF];
    
	char *COMANDOS[] = {"SHOW","TEST","WIPE", "EXIT"};
    char *RESPUESTAS[] = {"OK","ER"};
    
	char *MENS_OK[] = {
		"=> HECHO, codificación binaria mostrada por los LEDs en la placa Altera",
		"=> CORRECTA, codificación binaria realizada exacta ",
		"=> OK, reinicializados los valores de los dispositivos" 
		};
	char *MENS_ER[] = {
		"=> Error desconocido",
		"=> INCORRECTA, codificación binaria mal realizada",
		"=> KO, no se han reinicializado los valores de los dispositivos" 
		};

	// Enviar comando al servidor    
    memset(buf, 0, TAMBUF);
    sprintf(buf,"%s:%d",COMANDOS[comando],param);
	tam = SSL_write(ssl,buf,strlen(buf));
		CHK_SSL(tam);
	if(DEBUG) printf("\n <<<< Comando enviado: %s >>>>\n ",buf);

	if(comando != 3){	
	// Esperar respuesta del servidor
	tam = SSL_read(ssl, buf, TAMBUF);
		CHK_SSL(tam);
	buf[tam]='\0';
	if(DEBUG) printf("<<<< Respuesta recibida: %s >>>>\n",buf);

    // Procesar respuesta recibida
	msg = atoi(&buf[3]);  
	if(strncmp(buf,RESPUESTAS[0],2) == 0){       // OK:msg
		printf("\n  %s\n", MENS_OK[msg]);
	} 
	else if(strncmp(buf,RESPUESTAS[1],2) == 0){  // ER:msg
		printf("\n  %s\n", MENS_ER[msg]);
	}
	else printf("\n ¡¡¡Respuesta desconocida!!!\n");

	printf("\nPulsa RETURN para continuar ...");
	fflush(stdin);
	getc(stdin);
	} // Cerrar Bucle Comandos

} // While final



// C compiler & debugger online
// https://www.onlinegdb.com/online_c_compiler
// Programación en C
// http://www.it.uc3m.es/pbasanta/asng/course_notes/c_programming_part_es.html
