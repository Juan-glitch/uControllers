
/* Altera_server_fin.c
   Autores: Andrea Cabrera y Juanjo Arin
   WARNING:
   Segundo bucle while no vuelve a aceptar conexion....
*/

#include <arpa/inet.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdbool.h> // JJ
#include <openssl/err.h>
#include <openssl/ssl.h>
#define CERTFILE "./certificados/s_cert.pem"
#define KEYFILE  "./certificados/s_key.pem"
// GPIO DIR CALLS
#include "./address_map_arm.h" // .. llamda padre si no hijo

#define CHK_NULL(x) if ((x)==NULL ) exit(-1);
#define CHK_ERR(err,s) if ((err)==-1) { perror(s); exit(-2); }
#define CHK_SSL(err) if ((err)==-1) { ERR_print_errors_fp(stderr); exit(-3); }

// Comunications
#define PORT 7777
#define TAMBUF 32





// FUNCIONES
void send_receive(int sock, int comando, int param);
int open_physical (int fd);
void close_physical (int fd);
void* map_physical(int fd, unsigned int base, unsigned int span);
int unmap_physical(void * virtual_base, unsigned int span);
// ...AUXILIARES
int ctoi (char ch);
int segmentos ( int number);

// ------------------------------- MAIN --------------------------------------------------------
int main()
{
    // Declaración de variables
    char *COMANDOS[] = {"SHOW","TEST","WIPE","EXIT"};
    char *RESPUESTAS[] = {"OK","ER"};
    int fd = -1;     // descriptor abrir /dev/mem para acceso a las direccion$
    int option=0, param=0, res;
    bool flag = false;
    // Cripto
    SSL_CTX *ctx;
    SSL *ssl;
    const SSL_METHOD *method;
    // Interfaz de sockets
    char buf[TAMBUF];
    int leidos, err;
    int sock, sock_dialogo;
    struct sockaddr_in dir;
    struct sockaddr_in clientdir;

    socklen_t len = sizeof(struct sockaddr); //Inicializado en IP local maq

    //Crear socket:
    sock = socket(AF_INET, SOCK_STREAM, 0);
    CHK_ERR(sock, "No se ha establecido el socket");

    //Asignar dirección al socket:
    bzero(&dir, sizeof(struct sockaddr));
    dir.sin_family = AF_INET;
    dir.sin_addr.s_addr = htonl(INADDR_ANY);
    dir.sin_port = htons(PORT);

    err = bind(sock, (struct sockaddr *)&dir, sizeof dir);
    CHK_ERR(err, "No se puede asignar dirección");

    //Establecer como socket de escucha:
    err = listen(sock, 5);
    CHK_ERR(err, "No se puede configurar el puerto de escucha");

    // Inicializar contexto SSL
    SSL_library_init();
    SSL_load_error_strings();
    method = TLSv1_2_server_method();
    ctx = SSL_CTX_new(method);
    CHK_NULL(ctx);

    // Cargar cerfificados desde ficheros
    err = SSL_CTX_use_certificate_file(ctx, CERTFILE, SSL_FILETYPE_PEM) ;
    CHK_SSL(err);
    // Cargar clave privada
    err = SSL_CTX_use_PrivateKey_file(ctx, KEYFILE, SSL_FILETYPE_PEM) ;
    CHK_SSL(err);
    // Verificar clave privada
    err = SSL_CTX_check_private_key(ctx);
    CHK_ERR(err,"Clave privada no se corresponde con certificado\n");

    // Interfaz GPIO
    volatile int * LEDR_ptr; // red LED address
    volatile int * HEX3_HEX0_ptr; // HEX3_HEX0 address
    volatile int * SW_switch_ptr; // SW slider switch address
    volatile int * KEY_ptr; // pushbutton KEY address
    void *LW_virtual;

    // inicializa mapeo para acceder a la memoria física
    if ((fd = open_physical (fd)) == -1) // crea acceso a la memoria virtual
        return (-1);
    if ((LW_virtual = map_physical (fd, LW_BRIDGE_BASE, LW_BRIDGE_SPAN)) == NULL)
        return (-1);
    // establece puntero al puerto I/O
    LEDR_ptr      = ( unsigned int *)(LW_virtual + LEDR_BASE);
    HEX3_HEX0_ptr = ( unsigned int *)(LW_virtual + HEX3_HEX0_BASE);
    SW_switch_ptr = ( unsigned int *)(LW_virtual + SW_BASE);
    KEY_ptr       = ( unsigned int *)(LW_virtual + KEY_BASE);
    
// SERVER EN ESCUCHA (No funciona)
// while(1){


                        // Bloqueo a la espera de aceptar conexión:
                        sock_dialogo = accept(sock, (struct sockaddr*)&clientdir, &len);                /* accept connection */
                        CHK_ERR(sock_dialogo, "Conexión no establecida");
                        printf("Conexión desde: %s:%d\n", inet_ntoa(clientdir.sin_addr), ntohs(clientdir.sin_port));

                        // Obtener estado SSL del contexto establecido
                        ssl = SSL_new(ctx);
                        CHK_NULL(ssl);

                        // Incorporar socket al estado SSL
                        SSL_set_fd(ssl, sock_dialogo);

                        // Establecer conexión segura
                        err = SSL_accept(ssl);
                        CHK_SSL(err);
                        printf("Conexión cifrada con %s\n", SSL_get_cipher(ssl));
                // COMUNICACION SOCKET
     while(!flag){
                    //Leer mensaje:
                        memset(buf, 0, TAMBUF);
                        leidos = SSL_read(ssl, buf, TAMBUF);
                        CHK_SSL(leidos);

                        // Procesar respuesta
                        if(strncmp(buf,COMANDOS[0],4)==0) {option = 0;}
                        if(strncmp(buf,COMANDOS[1],4)==0) {option = 1;}
                        if(strncmp(buf,COMANDOS[2],4)==0) {option = 2;}
                        if(strncmp(buf,COMANDOS[3],4)==0) {option = 3;}
                        //Procesar parametro
                        param = atoi(&buf[5]);//Numero

                        switch(option){
				                // SHOW
                                case 0:
                                //Escribir parametro en display y Leds
                                *HEX3_HEX0_ptr = segmentos(param);
                                *LEDR_ptr = param;
                                //Esperar a que pulse un boton
                                while(*KEY_ptr == 0);
                                res = 0; //OK
                                //ApagarLeds y display
                                *LEDR_ptr = 0x0;
                                *HEX3_HEX0_ptr = 0x0;
                                break;
                               // TEST
                                case 1:
                                        //Escribir parametro en display
                                        *HEX3_HEX0_ptr = segmentos(param);

                                        //Esperar a que pulse un boton
                                        while(*KEY_ptr == 0);

                                        //Comprobar que ha codificado correctamente
                                        if(param != *SW_switch_ptr){
                                            *HEX3_HEX0_ptr = segmentos(0);
                                            res = 1; //Error
                                        }
                                        else{
                                            *HEX3_HEX0_ptr = segmentos(1);
                                            res = 0; //Ok
                                        }
                                        break;
                               //WIPE
                                case 2:
                                 //Escribir parametro en display
                                 *HEX3_HEX0_ptr = segmentos(0);
                                 //Esperar a que pulse un boton
                                  while(*KEY_ptr == 0);
                                 //Apagar Leds y display
                                  *LEDR_ptr = 0x0;
                                  *HEX3_HEX0_ptr = 0x0;
                                //Comprobar que ha bajado los SW
                                  if(*SW_switch_ptr != 0) res = 1;
                                  else res = 0;
                                   break;

                                //EXIT
                                case 3:
                                flag = true;
                                res = 0; //Ok
                        }

        if(flag) break; // Salir Bucle Socket
    
        //Enviar comando al servidor
        sprintf(buf,"%s:%d",RESPUESTAS[res],option);
        err = SSL_write(ssl, buf, leidos);      
        CHK_ERR(err, "Error de escritura");     

      } //BUCLE 2:Cerrar conexió
    close(sock_dialogo);
    // Liberar contexto ssl
    SSL_free(ssl);
    SSL_CTX_free(ctx);
   // } // BUCLE 1: ESTABLECER CONEXION 

     exit(0);
 } // While final
 
 //-------------------------------------------------------------------------------------------------------------//

// FUNCIONES

/* ctoi: 
   DEF: codificar CARACTER recibido a integer
   IN: caracter
   OUT = Numero*/
int ctoi (char ch){
        if (ch >= '0' && ch <= '9' ) return ch - '0';
        return -1; //error
}

/* SEGMENTOS: 
   DEF: codificar número decimal para 7-segment displays
   IN: numero
   OUT = valor 4 registro display*/
   int segmentos ( int number) {
   char digitos[5]={'\0'};
   int c, i;
   int SEG_HEX[]={0x3F, 0x06, 0x5B, 0x4F,0x66,0x6D, 0x7D, 0x07, 0x7F, 0xEF}; 

   sprintf(digitos,"%d",number);  
   c = 0x0;
   for (i=0;i<strlen(digitos);i++){
                c = c << 8 | SEG_HEX[ctoi(digitos[i])];
   }
   return c;
}


/* virtual_base:
Establece un mapeo de direcciones virtuales con direcciones físicas, con inicio
en X y que se extiende Y span T bytes */
void* map_physical(int fd, unsigned int base, unsigned int span)
{
 void *virtual_base;
 virtual_base = mmap (NULL, span, (PROT_READ | PROT_WRITE), MAP_SHARED, fd, base);
 if (virtual_base == MAP_FAILED)
 {
 printf ("ERROR: mmap() failed...\n");
 close (fd);
 return (NULL);
 }
 return virtual_base;
}
/* unmap_physical:
Libera el mapeo de direcciones virtuales previamente establecido */
int unmap_physical(void * virtual_base, unsigned int span)
{
 if (munmap (virtual_base, span) != 0)
 {
 printf ("ERROR: munmap() failed...\n");
 return (-1);
 }
 return 0;
}

/* open_physical;
Abre el dispositivo /dev/mem, si no lo está ya, para dar acceso al direccionamiento
físico */
int open_physical (int fd)
{
 if (fd == -1)
 if ((fd = open( "/dev/mem", (O_RDWR | O_SYNC))) == -1)
 {
 printf ("ERROR: could not open \"/dev/mem\"...\n");
 return (-1);
 }
 return fd;
}
/* Cierra el dispositivo /dev/mem */
void close_physical (int fd)
{
 close (fd);
}





